package languages

var SupportedLanguages []string = []string{
	"java",
	"python",
	// "go",
	// "node",
	// "rust",
	// "c/c++",
	// "kotlin",
}

var defaultLang = "java"
